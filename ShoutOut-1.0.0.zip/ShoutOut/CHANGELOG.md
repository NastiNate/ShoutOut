# Shout Out changelog

## 1.0.0 (November 2026)

First public release.

- Trade chat ads for Enchanting, Leatherworking, Alchemy, Blacksmithing, Tailoring, Engineering and Cooking, plus Mage (portals, food and water), Warlock (summons) and Custom (bag items) ads.
- Write your own message with `{prof}`, `{items}`, `{enchants}`, `{portals}` and `{places}` placeholders, or use each ad type's example message.
- Clickable item, recipe and profession links, with gold / silver / copper prices and stack / each pricing.
- Messages packed to WoW's 255-character limit, with optional Rotate overflow into a second post. If WoW refuses a post as too long, Shout Out trims and retries automatically.
- AH estimates and material costs from Auctionator or TradeSkillMaster.
- Several ads with their own colors, a quick-post bar, a minimap button, reminders and auto-invite.
- Send test to me: see the exact ad in your chat, visible only to you.
- Preview a profession to build ads for professions you don't have (test messages only).
- How it Works guide inside the addon.
